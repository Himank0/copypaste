package com.payflow.invoice;

import com.payflow.common.CurrentUser;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;
    private final CurrentUser currentUser;

    public InvoiceController(InvoiceService invoiceService, CurrentUser currentUser) {
        this.invoiceService = invoiceService;
        this.currentUser = currentUser;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Invoice create(@Valid @RequestBody CreateInvoiceRequest request, HttpServletRequest httpRequest) {
        return invoiceService.create(currentUser.idFrom(httpRequest), request);
    }

    @GetMapping
    public List<Invoice> getMine(@RequestParam(required = false) InvoiceStatus status,
                                  HttpServletRequest httpRequest) {
        return invoiceService.getForUser(currentUser.idFrom(httpRequest), status);
    }

    @GetMapping("/{id}")
    public Invoice getOne(@PathVariable String id, HttpServletRequest httpRequest) {
        return invoiceService.getOwned(currentUser.idFrom(httpRequest), id);
    }

    @PostMapping("/{id}/send")
    public Invoice send(@PathVariable String id, HttpServletRequest httpRequest) {
        return invoiceService.send(currentUser.idFrom(httpRequest), id);
    }

    @PostMapping("/{id}/pay")
    public Invoice markPaid(@PathVariable String id, HttpServletRequest httpRequest) {
        return invoiceService.markPaid(currentUser.idFrom(httpRequest), id);
    }
}
