package com.payflow.invoice;

import com.payflow.common.NotFoundException;
import com.payflow.common.UnauthorizedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class InvoiceService {

    private static final Logger log = LoggerFactory.getLogger(InvoiceService.class);

    private final InvoiceRepository invoiceRepository;

    public InvoiceService(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    /** Creates an invoice, auto-calculating its total from line items and tax rate. */
    public Invoice create(String userId, CreateInvoiceRequest request) {
        List<LineItem> lineItems = request.lineItems().stream()
                .map(li -> new LineItem(li.description(), li.quantity(), li.unitPrice()))
                .collect(Collectors.toList());

        Invoice invoice = new Invoice(userId, request.clientName(), lineItems,
                request.taxRate(), request.dueDate());
        invoice.recalculateTotal();
        Invoice saved = invoiceRepository.save(invoice);
        log.info("Invoice {} created for user {}", saved.getId(), userId);
        return saved;
    }

    /** Returns the caller's invoices, optionally filtered by status, with overdue flags refreshed. */
    public List<Invoice> getForUser(String userId, InvoiceStatus statusFilter) {
        List<Invoice> invoices = statusFilter == null
                ? invoiceRepository.findByCreatorUserId(userId)
                : invoiceRepository.findByCreatorUserIdAndStatus(userId, statusFilter);

        invoices.forEach(invoice -> invoice.markOverdueIfPastDue(LocalDate.now()));
        return invoiceRepository.saveAll(invoices);
    }

    /** Fetches a single invoice, enforcing that it belongs to the caller. */
    public Invoice getOwned(String userId, String invoiceId) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new NotFoundException("Invoice not found: " + invoiceId));
        assertOwnership(userId, invoice);
        invoice.markOverdueIfPastDue(LocalDate.now());
        return invoiceRepository.save(invoice);
    }

    /** Marks an invoice as sent. */
    public Invoice send(String userId, String invoiceId) {
        Invoice invoice = getOwnedRaw(userId, invoiceId);
        invoice.markSent();
        return invoiceRepository.save(invoice);
    }

    /** Records payment against an invoice, marking it paid. */
    public Invoice markPaid(String userId, String invoiceId) {
        Invoice invoice = getOwnedRaw(userId, invoiceId);
        invoice.markPaid();
        Invoice saved = invoiceRepository.save(invoice);
        log.info("Invoice {} marked paid by user {}", invoiceId, userId);
        return saved;
    }

    private Invoice getOwnedRaw(String userId, String invoiceId) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new NotFoundException("Invoice not found: " + invoiceId));
        assertOwnership(userId, invoice);
        return invoice;
    }

    private void assertOwnership(String userId, Invoice invoice) {
        if (!invoice.getCreatorUserId().equals(userId)) {
            throw new UnauthorizedException("Cannot access another user's invoice");
        }
    }
}
