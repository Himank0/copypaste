package com.payflow.invoice;

public enum InvoiceStatus {
    DRAFT, SENT, PAID, OVERDUE
}
