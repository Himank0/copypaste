package com.payflow.invoice;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "invoices")
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(nullable = false)
    private String creatorUserId;

    @Column(nullable = false)
    private String clientName;

    @ElementCollection
    @CollectionTable(name = "invoice_line_items", joinColumns = @JoinColumn(name = "invoice_id"))
    private List<LineItem> lineItems = new ArrayList<>();

    @Column(nullable = false)
    private BigDecimal taxRate;

    @Column(nullable = false)
    private BigDecimal total;

    @Column(nullable = false)
    private LocalDate dueDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private InvoiceStatus status = InvoiceStatus.DRAFT;

    @Column(nullable = false)
    private Instant createdAt = Instant.now();

    protected Invoice() {
        // required by JPA
    }

    public Invoice(String creatorUserId, String clientName, List<LineItem> lineItems,
                   BigDecimal taxRate, LocalDate dueDate) {
        this.creatorUserId = creatorUserId;
        this.clientName = clientName;
        this.lineItems = lineItems;
        this.taxRate = taxRate;
        this.dueDate = dueDate;
    }

    public void recalculateTotal() {
        BigDecimal subtotal = lineItems.stream()
                .map(LineItem::lineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        this.total = subtotal.add(subtotal.multiply(taxRate));
    }

    public void markSent() {
        this.status = InvoiceStatus.SENT;
    }

    public void markPaid() {
        this.status = InvoiceStatus.PAID;
    }

    public void markOverdueIfPastDue(LocalDate today) {
        if (status != InvoiceStatus.PAID && dueDate.isBefore(today)) {
            this.status = InvoiceStatus.OVERDUE;
        }
    }

    public String getId() {
        return id;
    }

    public String getCreatorUserId() {
        return creatorUserId;
    }

    public String getClientName() {
        return clientName;
    }

    public List<LineItem> getLineItems() {
        return lineItems;
    }

    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public InvoiceStatus getStatus() {
        return status;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
