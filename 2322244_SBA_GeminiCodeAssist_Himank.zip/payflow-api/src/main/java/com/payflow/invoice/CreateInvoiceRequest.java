package com.payflow.invoice;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record CreateInvoiceRequest(
        @NotBlank String clientName,
        @NotEmpty @Valid List<LineItemRequest> lineItems,
        @NotNull @DecimalMin("0.0") BigDecimal taxRate,
        @NotNull @Future LocalDate dueDate
) {
    public record LineItemRequest(
            @NotBlank String description,
            @Positive int quantity,
            @NotNull @DecimalMin(value = "0.01") BigDecimal unitPrice
    ) {
    }
}
