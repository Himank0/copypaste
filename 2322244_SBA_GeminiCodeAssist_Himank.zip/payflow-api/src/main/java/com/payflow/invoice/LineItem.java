package com.payflow.invoice;

import jakarta.persistence.Embeddable;

import java.math.BigDecimal;

@Embeddable
public class LineItem {

    private String description;
    private int quantity;
    private BigDecimal unitPrice;

    protected LineItem() {
        // required by JPA
    }

    public LineItem(String description, int quantity, BigDecimal unitPrice) {
        this.description = description;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    public BigDecimal lineTotal() {
        return unitPrice.multiply(BigDecimal.valueOf(quantity));
    }

    public String getDescription() {
        return description;
    }

    public int getQuantity() {
        return quantity;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }
}
