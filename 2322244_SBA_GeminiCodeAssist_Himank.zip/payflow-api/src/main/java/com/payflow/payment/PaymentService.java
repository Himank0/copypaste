package com.payflow.payment;

import com.payflow.common.NotFoundException;
import com.payflow.common.UnauthorizedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    private final PaymentRepository paymentRepository;

    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    /** Creates a payment record for the given user. */
    public Payment create(String userId, BigDecimal amount) {
        if (amount == null || amount.signum() <= 0) {
            throw new IllegalArgumentException("Payment amount must be positive");
        }
        Payment saved = paymentRepository.save(new Payment(userId, amount));
        log.info("Payment {} created for user {}", saved.getId(), userId);
        return saved;
    }

    /** Returns all payments belonging to the given user only. */
    public List<Payment> getByUser(String userId) {
        return paymentRepository.findByUserId(userId);
    }

    /**
     * Deletes a single payment, scoped to its owner.
     * The original AI-generated "delete-all" function deleted every payment
     * in the table with no user scoping - a critical data-loss/authorization
     * flaw. It has been replaced with an ownership-checked single-record delete.
     */
    public void delete(String userId, String paymentId) {
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new NotFoundException("Payment not found: " + paymentId));
        if (!payment.getUserId().equals(userId)) {
            throw new UnauthorizedException("Cannot delete another user's payment");
        }
        paymentRepository.delete(payment);
        log.info("Payment {} deleted by user {}", paymentId, userId);
    }
}
