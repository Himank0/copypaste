package com.payflow.payment;

import com.payflow.common.CurrentUser;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;
    private final CurrentUser currentUser;

    public PaymentController(PaymentService paymentService, CurrentUser currentUser) {
        this.paymentService = paymentService;
        this.currentUser = currentUser;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Payment create(@Valid @RequestBody CreatePaymentRequest request, HttpServletRequest httpRequest) {
        return paymentService.create(currentUser.idFrom(httpRequest), request.amount());
    }

    @GetMapping
    public List<Payment> getMine(HttpServletRequest httpRequest) {
        return paymentService.getByUser(currentUser.idFrom(httpRequest));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String id, HttpServletRequest httpRequest) {
        paymentService.delete(currentUser.idFrom(httpRequest), id);
    }
}
