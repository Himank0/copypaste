package com.payflow.common;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

/**
 * Resolves the authenticated user's id for the current request.
 * Placeholder for real auth (e.g. Spring Security JWT) - in production,
 * this would read from the SecurityContext instead of a header.
 */
@Component
public class CurrentUser {

    public String idFrom(HttpServletRequest request) {
        String userId = request.getHeader("X-User-Id");
        if (userId == null || userId.isBlank()) {
            throw new UnauthorizedException("Missing authenticated user");
        }
        return userId;
    }
}
