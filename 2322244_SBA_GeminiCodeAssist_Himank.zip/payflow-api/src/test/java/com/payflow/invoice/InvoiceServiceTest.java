package com.payflow.invoice;

import com.payflow.common.UnauthorizedException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class InvoiceServiceTest {

    private InvoiceRepository invoiceRepository;
    private InvoiceService invoiceService;
    private Validator validator;

    @BeforeEach
    void setUp() {
        invoiceRepository = mock(InvoiceRepository.class);
        invoiceService = new InvoiceService(invoiceRepository);
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
        // save/saveAll just return whatever was passed in, like a real repo would
        when(invoiceRepository.save(any(Invoice.class))).thenAnswer(inv -> inv.getArgument(0));
        when(invoiceRepository.saveAll(any())).thenAnswer(inv -> inv.getArgument(0));
    }

    private CreateInvoiceRequest requestWith(List<CreateInvoiceRequest.LineItemRequest> items, BigDecimal taxRate) {
        return new CreateInvoiceRequest("Acme Corp", items, taxRate, LocalDate.now().plusDays(30));
    }

    @Test
    void calculatesTotalFromMultipleLineItemsAndTax() {
        var items = List.of(
                new CreateInvoiceRequest.LineItemRequest("Consulting", 2, new BigDecimal("100.00")),
                new CreateInvoiceRequest.LineItemRequest("Design", 1, new BigDecimal("50.00"))
        );
        Invoice invoice = invoiceService.create("user-1", requestWith(items, new BigDecimal("0.10")));

        // subtotal = 250.00, tax = 25.00 -> total = 275.00
        assertEquals(new BigDecimal("275.00"), invoice.getTotal());
    }

    @Test
    void statusTransitionsFromDraftToSentToPaid() {
        Invoice invoice = new Invoice("user-1", "Acme", List.of(
                new LineItem("Item", 1, BigDecimal.TEN)), BigDecimal.ZERO, LocalDate.now().plusDays(10));
        invoice.recalculateTotal();
        when(invoiceRepository.findById("inv-1")).thenReturn(Optional.of(invoice));

        assertEquals(InvoiceStatus.DRAFT, invoice.getStatus());

        invoiceService.send("user-1", "inv-1");
        assertEquals(InvoiceStatus.SENT, invoice.getStatus());

        invoiceService.markPaid("user-1", "inv-1");
        assertEquals(InvoiceStatus.PAID, invoice.getStatus());
    }

    @Test
    void flagsInvoiceAsOverdueWhenPastDueDateAndUnpaid() {
        Invoice invoice = new Invoice("user-1", "Acme", List.of(
                new LineItem("Item", 1, BigDecimal.TEN)), BigDecimal.ZERO, LocalDate.now().minusDays(1));
        invoice.recalculateTotal();
        when(invoiceRepository.findById("inv-1")).thenReturn(Optional.of(invoice));

        Invoice result = invoiceService.getOwned("user-1", "inv-1");

        assertEquals(InvoiceStatus.OVERDUE, result.getStatus());
    }

    @Test
    void rejectsNegativeLineItemAmountAtValidation() {
        var items = List.of(new CreateInvoiceRequest.LineItemRequest("Bad item", 1, new BigDecimal("-5.00")));
        CreateInvoiceRequest request = requestWith(items, BigDecimal.ZERO);

        Set<ConstraintViolation<CreateInvoiceRequest>> violations = validator.validate(request);

        assertFalse(violations.isEmpty(), "Negative unit price should fail bean validation");
    }

    @Test
    void rejectsInvoiceWithZeroLineItems() {
        CreateInvoiceRequest request = requestWith(List.of(), BigDecimal.ZERO);

        Set<ConstraintViolation<CreateInvoiceRequest>> violations = validator.validate(request);

        assertFalse(violations.isEmpty(), "Empty line items should fail bean validation (@NotEmpty)");
    }

    @Test
    void deniesAccessToAnotherUsersInvoice() {
        Invoice invoice = new Invoice("owner-user", "Acme", List.of(
                new LineItem("Item", 1, BigDecimal.TEN)), BigDecimal.ZERO, LocalDate.now().plusDays(10));
        when(invoiceRepository.findById("inv-1")).thenReturn(Optional.of(invoice));

        assertThrows(UnauthorizedException.class,
                () -> invoiceService.getOwned("someone-else", "inv-1"));
    }
}
