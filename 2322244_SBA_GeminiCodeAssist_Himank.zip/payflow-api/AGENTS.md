# AGENTS.md — PayFlow API Project Standards

Read by Antigravity IDE (and other AGENTS.md-compatible agents) at session start.
Google Code Assist / Gemini CLI is sunset as of June 18, 2026; this file replaces
the old `.gemini/GEMINI.md` convention used previously.

## Stack
- Java 17, Spring Boot 3.3
- Spring Data JPA (H2 for dev/tests) — no raw JDBC/database drivers
- Maven build

## Architecture
Layered, one package per domain: `entity → repository → service → controller`.
- Controllers: HTTP + validation only, no business logic.
- Services: business rules, ownership checks, logging. All public methods documented.
- Repositories: `JpaRepository` interfaces only.
- Domain-specific exceptions (`NotFoundException`, `UnauthorizedException`) mapped
  centrally in `common/GlobalExceptionHandler` — do not `try/catch` + return raw
  status codes in controllers.

## Security
- Every query/mutation on a user-owned resource (Payment, Invoice) must be scoped
  to the authenticated user. Never expose a bulk/unscoped delete or list operation.
- Validate all inbound DTOs with `jakarta.validation` annotations.

## Testing
- Business logic (service layer) gets unit tests with Mockito-mocked repositories.
- Cover: happy path, validation failure, and at least one authorization-denial case
  per feature.

## Agent instructions
- Don't over-engineer: no unnecessary abstraction layers, mappers, or frameworks
  beyond what's listed above unless asked.
- Prefer editing existing files over introducing new patterns.
