# PROMPTS.md — Codex Prompt Chain for the Expense Splitting Feature

All prompts below assume Codex has already read `AGENTS.md` at the repo root.
Surfaces used: **Web**, **CLI**, and the **IDE extension**. Techniques used:
role-based, constraint-based, decomposition, specificity, and iterative
refinement (5 total, satisfying the "at least 3" requirement).

## Prompt Chain (execution order)

### 1. Remediate the Transaction module
- **Surface:** Web
- **Technique:** Role-based + constraint-based
- **Prompt text:**
  > "You are a senior Spring Boot engineer at a fintech company doing a
  > security-focused rewrite. Replace the Transaction feature entirely with a
  > layered implementation: JPA entity, Spring Data repository, a service
  > layer that enforces the caller can only read/update/delete their own
  > transactions, and a thin controller. Follow every rule in AGENTS.md,
  > especially the security and testing sections. Do not use raw JDBC."
- **Rationale:** Role framing pushes Codex toward production-grade defaults
  rather than demo code; explicit constraints re-anchor it on the exact
  AGENTS.md rules most likely to be skipped (ORM-only, ownership checks).

### 2. Shared Expense model
- **Surface:** IDE extension (inline, in `expense/model/`)
- **Technique:** Specificity
- **Prompt text:**
  > "Add a SharedExpense JPA entity with: creatorUserId, description,
  > totalAmount (BigDecimal), a SplitType enum (EQUAL, CUSTOM), createdAt,
  > and a one-to-many list of ExpenseParticipant (userId, shareAmount).
  > Follow the same entity conventions as Transaction.java in this package."
- **Rationale:** Working inline in the IDE with the existing `Transaction`
  entity visible let the prompt say "same conventions as" instead of
  re-specifying every convention, which kept the prompt short and precise.

### 3. Balance calculation service
- **Surface:** Web
- **Technique:** Decomposition
- **Prompt text:**
  > "Create BalanceCalculationService with two responsibilities only:
  > (1) calculateShares(totalAmount, splitType, participants) that supports
  > EQUAL splits (with penny-remainder distributed deterministically) and
  > CUSTOM splits (validating the amounts sum exactly to totalAmount), and
  > (2) computeNetBalances(userId, expenses) that nets what a user owes/is
  > owed per counterpart across multiple expenses. No persistence, no HTTP
  > concerns in this class."
- **Rationale:** Splitting "calculate shares" from "net balances" into two
  named methods up front avoided Codex collapsing both concerns into one
  hard-to-test method, which is what happened on the first attempt (see
  Post-Generation Corrections).

### 4. Expense service + controller
- **Surface:** CLI
- **Technique:** Constraint-based
- **Prompt text:**
  > "codex exec: Add ExpenseService (persistence + delegates math to
  > BalanceCalculationService) and ExpenseController with POST
  > /api/v1/expenses and GET /api/v1/expenses/balances. Controller must not
  > call the repository directly. Resolve the caller via CurrentUserProvider,
  > the same pattern TransactionController uses."
- **Rationale:** CLI batch mode suited a mechanical "wire these layers
  together" task with no ambiguity left to resolve; constraining it to reuse
  the existing `CurrentUserProvider` pattern kept the two features consistent.

### 5. Test suite
- **Surface:** Web
- **Technique:** Few-shot + iterative refinement
- **Prompt text:**
  > "Write JUnit 5 + Mockito + AssertJ tests for BalanceCalculationService
  > and TransactionService. Cover: equal split among 3 participants; custom
  > split matching the total; custom split that doesn't sum correctly
  > (expect ValidationException); net balance across two expenses between
  > the same two users; a 1-participant expense (expect ValidationException);
  > and an unauthorized access attempt (expect UnauthorizedAccessException).
  > Example test shape: [pasted one existing test class as a few-shot example]."
- **Rationale:** Pasting one already-reviewed test class as a few-shot
  example got Codex to match the project's assertion style (AssertJ
  `assertThatThrownBy`) on the first pass instead of defaulting to
  JUnit's `assertThrows`.

## Post-Generation Corrections

Every material change made to Codex's output after reviewing the diff:

1. **Split-calculation method did too much (Prompt 3).** The first
   generation put share calculation, persistence, *and* net-balance math
   into one `ExpenseService` method. Fixed by re-prompting with the explicit
   two-method decomposition shown above, then manually confirming
   `BalanceCalculationService` had zero repository/entity-manager imports.
2. **Equal-split rounding was non-deterministic (Prompt 3).** The generated
   equal-split logic divided the total and let the *last* participant absorb
   all rounding remainder, which meant reordering the participant list
   changed who got the odd cent. Manually rewrote the remainder distribution
   to assign leftover pennies to the first N participants deterministically,
   and added an explicit assertion for it in the test suite.
3. **Controller called the repository directly (Prompt 4).** The CLI output
   initially injected `SharedExpenseRepository` straight into
   `ExpenseController` for the balances endpoint "for simplicity." Rejected
   the diff and re-ran the prompt with the explicit constraint restated;
   the second pass routed everything through `ExpenseService`.
4. **Custom-split validation used floating-point comparison (Prompt 3).**
   Initial generation summed `double` values and compared with `==`,
   which is unsafe for currency. Manually replaced with `BigDecimal` and a
   scale-normalized `compareTo`.
