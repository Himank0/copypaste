package com.fintrack.transactions;

import com.fintrack.common.exception.UnauthorizedAccessException;
import com.fintrack.transactions.dto.TransactionRequest;
import com.fintrack.transactions.model.Transaction;
import com.fintrack.transactions.repository.TransactionRepository;
import com.fintrack.transactions.service.TransactionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransactionServiceTest {

    @Mock
    private TransactionRepository transactionRepository;

    private TransactionService transactionService;

    @BeforeEach
    void setUp() {
        transactionService = new TransactionService(transactionRepository);
    }

    @Test
    void unauthorisedAccessAttemptToAnotherUsersTransactionIsRejected() {
        Long ownerId = 1L;
        Long attackerId = 2L;
        Transaction ownedByUser1 = new Transaction(ownerId, new BigDecimal("25.00"), "food", "lunch");
        when(transactionRepository.findById(99L)).thenReturn(Optional.of(ownedByUser1));

        assertThatThrownBy(() -> transactionService.getTransactionForUser(attackerId, 99L))
                .isInstanceOf(UnauthorizedAccessException.class);
    }

    @Test
    void unauthorisedUpdateAttemptIsRejectedBeforeAnyWrite() {
        Long ownerId = 1L;
        Long attackerId = 2L;
        Transaction ownedByUser1 = new Transaction(ownerId, new BigDecimal("25.00"), "food", "lunch");
        when(transactionRepository.findById(99L)).thenReturn(Optional.of(ownedByUser1));

        TransactionRequest maliciousUpdate = new TransactionRequest(new BigDecimal("0.01"), "hack", "x");

        assertThatThrownBy(() -> transactionService.updateTransaction(attackerId, 99L, maliciousUpdate))
                .isInstanceOf(UnauthorizedAccessException.class);
    }
}
