package com.fintrack.expense;

import com.fintrack.common.exception.ValidationException;
import com.fintrack.expense.dto.ParticipantInput;
import com.fintrack.expense.model.ExpenseParticipant;
import com.fintrack.expense.model.SharedExpense;
import com.fintrack.expense.model.SplitType;
import com.fintrack.expense.service.BalanceCalculationService;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class BalanceCalculationServiceTest {

    private final BalanceCalculationService service = new BalanceCalculationService();

    @Test
    void equalSplitAmongThreeParticipantsSumsToTotalAndHandlesRounding() {
        List<ParticipantInput> participants = List.of(
                new ParticipantInput(1L, null),
                new ParticipantInput(2L, null),
                new ParticipantInput(3L, null)
        );

        List<ExpenseParticipant> shares = service.calculateShares(
                new BigDecimal("100.00"), SplitType.EQUAL, participants);

        assertThat(shares).hasSize(3);
        BigDecimal sum = shares.stream().map(ExpenseParticipant::getShareAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        assertThat(sum).isEqualTo(new BigDecimal("100.00"));
        // 100 / 3 = 33.33 with 1 cent leftover assigned to the first participant.
        assertThat(shares.get(0).getShareAmount()).isEqualTo(new BigDecimal("33.34"));
        assertThat(shares.get(1).getShareAmount()).isEqualTo(new BigDecimal("33.33"));
        assertThat(shares.get(2).getShareAmount()).isEqualTo(new BigDecimal("33.33"));
    }

    @Test
    void customSplitWithAmountsMatchingTotalIsAccepted() {
        List<ParticipantInput> participants = List.of(
                new ParticipantInput(1L, new BigDecimal("60.00")),
                new ParticipantInput(2L, new BigDecimal("40.00"))
        );

        List<ExpenseParticipant> shares = service.calculateShares(
                new BigDecimal("100.00"), SplitType.CUSTOM, participants);

        assertThat(shares).extracting(ExpenseParticipant::getShareAmount)
                .containsExactly(new BigDecimal("60.00"), new BigDecimal("40.00"));
    }

    @Test
    void customSplitWhereAmountsDoNotSumToTotalFailsValidation() {
        List<ParticipantInput> participants = List.of(
                new ParticipantInput(1L, new BigDecimal("60.00")),
                new ParticipantInput(2L, new BigDecimal("30.00"))
        );

        assertThatThrownBy(() -> service.calculateShares(
                new BigDecimal("100.00"), SplitType.CUSTOM, participants))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("do not sum to the total");
    }

    @Test
    void expenseWithOnlyOneParticipantFailsValidation() {
        List<ParticipantInput> participants = List.of(new ParticipantInput(1L, null));

        assertThatThrownBy(() -> service.calculateShares(
                new BigDecimal("50.00"), SplitType.EQUAL, participants))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("at least 2 participants");
    }

    @Test
    void netBalanceBetweenTwoUsersAcrossMultipleExpensesIsSummed() {
        // Expense 1: user 1 pays, users 1 & 2 split equally -> user 2 owes user 1 50.00
        SharedExpense dinner = new SharedExpense(1L, "Dinner", new BigDecimal("100.00"), SplitType.EQUAL);
        dinner.addParticipant(new ExpenseParticipant(1L, new BigDecimal("50.00")));
        dinner.addParticipant(new ExpenseParticipant(2L, new BigDecimal("50.00")));

        // Expense 2: user 2 pays, users 1 & 2 split equally -> user 1 owes user 2 20.00
        SharedExpense taxi = new SharedExpense(2L, "Taxi", new BigDecimal("40.00"), SplitType.EQUAL);
        taxi.addParticipant(new ExpenseParticipant(1L, new BigDecimal("20.00")));
        taxi.addParticipant(new ExpenseParticipant(2L, new BigDecimal("20.00")));

        Map<Long, BigDecimal> netForUser1 = service.computeNetBalances(1L, List.of(dinner, taxi));

        // user 2 owes user 1: +50 (dinner) - 20 (taxi, user1 owes user2) = net +30
        assertThat(netForUser1.get(2L)).isEqualTo(new BigDecimal("30.00"));
    }
}
