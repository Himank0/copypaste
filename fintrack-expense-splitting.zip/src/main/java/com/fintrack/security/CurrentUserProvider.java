package com.fintrack.security;

import com.fintrack.common.exception.ValidationException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Resolves the "current" authenticated user for the request.
 *
 * FinTrack's identity/session layer sits in a separate service that is
 * out of scope for this feature. Until requests are wired through the
 * real gateway, the caller's identity is carried in the {@code X-User-Id}
 * header (set by the gateway after authentication). Every service method
 * that reads or writes user-owned data must call {@link #requireCurrentUserId(HttpServletRequest)}
 * so ownership can be enforced consistently.
 */
@Component
public class CurrentUserProvider {

    public static final String USER_ID_HEADER = "X-User-Id";

    public Long requireCurrentUserId(HttpServletRequest request) {
        String header = request.getHeader(USER_ID_HEADER);
        if (header == null || header.isBlank()) {
            throw new ValidationException("Missing required header: " + USER_ID_HEADER);
        }
        try {
            return Long.parseLong(header.trim());
        } catch (NumberFormatException ex) {
            throw new ValidationException(USER_ID_HEADER + " must be a numeric user id");
        }
    }

    public Long requireCurrentUserId() {
        ServletRequestAttributes attrs =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attrs == null) {
            throw new ValidationException("No active request to resolve current user from");
        }
        return requireCurrentUserId(attrs.getRequest());
    }
}
