package com.fintrack.transactions.service;

import com.fintrack.common.exception.ResourceNotFoundException;
import com.fintrack.common.exception.UnauthorizedAccessException;
import com.fintrack.transactions.dto.TransactionRequest;
import com.fintrack.transactions.model.Transaction;
import com.fintrack.transactions.repository.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Business logic for creating, reading, updating and deleting
 * transactions. Every method that touches an existing transaction
 * verifies the caller owns it before acting on it.
 */
@Service
public class TransactionService {

    private static final Logger log = LoggerFactory.getLogger(TransactionService.class);

    private final TransactionRepository transactionRepository;

    public TransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    @Transactional
    public Transaction createTransaction(Long userId, TransactionRequest request) {
        Transaction transaction = new Transaction(
                userId,
                request.amount(),
                request.category(),
                request.description()
        );
        Transaction saved = transactionRepository.save(transaction);
        log.info("Created transaction id={} for userId={}", saved.getId(), userId);
        return saved;
    }

    public List<Transaction> getTransactionsForUser(Long userId) {
        return transactionRepository.findByUserId(userId);
    }

    public Transaction getTransactionForUser(Long userId, Long transactionId) {
        Transaction transaction = findOrThrow(transactionId);
        assertOwnership(transaction, userId);
        return transaction;
    }

    @Transactional
    public Transaction updateTransaction(Long userId, Long transactionId, TransactionRequest request) {
        Transaction transaction = findOrThrow(transactionId);
        assertOwnership(transaction, userId);

        transaction.setAmount(request.amount());
        transaction.setCategory(request.category());
        transaction.setDescription(request.description());

        Transaction saved = transactionRepository.save(transaction);
        log.info("Updated transaction id={} for userId={}", transactionId, userId);
        return saved;
    }

    @Transactional
    public void deleteTransaction(Long userId, Long transactionId) {
        Transaction transaction = findOrThrow(transactionId);
        assertOwnership(transaction, userId);
        transactionRepository.delete(transaction);
        log.info("Deleted transaction id={} for userId={}", transactionId, userId);
    }

    private Transaction findOrThrow(Long transactionId) {
        return transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Transaction not found: " + transactionId));
    }

    private void assertOwnership(Transaction transaction, Long userId) {
        if (!transaction.getUserId().equals(userId)) {
            log.warn("userId={} attempted to access transaction id={} owned by userId={}",
                    userId, transaction.getId(), transaction.getUserId());
            throw new UnauthorizedAccessException(
                    "You do not have access to transaction " + transaction.getId());
        }
    }
}
