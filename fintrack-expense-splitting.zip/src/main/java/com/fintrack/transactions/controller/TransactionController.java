package com.fintrack.transactions.controller;

import com.fintrack.security.CurrentUserProvider;
import com.fintrack.transactions.dto.TransactionRequest;
import com.fintrack.transactions.dto.TransactionResponse;
import com.fintrack.transactions.model.Transaction;
import com.fintrack.transactions.service.TransactionService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * HTTP surface for transactions. Contains no business logic or data
 * access; every request resolves the caller's identity, then delegates
 * to {@link TransactionService}.
 */
@RestController
@RequestMapping("/api/v1/transactions")
public class TransactionController {

    private final TransactionService transactionService;
    private final CurrentUserProvider currentUserProvider;

    public TransactionController(TransactionService transactionService,
                                  CurrentUserProvider currentUserProvider) {
        this.transactionService = transactionService;
        this.currentUserProvider = currentUserProvider;
    }

    @PostMapping
    public ResponseEntity<TransactionResponse> create(@Valid @RequestBody TransactionRequest request,
                                                        HttpServletRequest httpRequest) {
        Long userId = currentUserProvider.requireCurrentUserId(httpRequest);
        Transaction created = transactionService.createTransaction(userId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(TransactionResponse.from(created));
    }

    @GetMapping
    public ResponseEntity<List<TransactionResponse>> listMine(HttpServletRequest httpRequest) {
        Long userId = currentUserProvider.requireCurrentUserId(httpRequest);
        List<TransactionResponse> responses = transactionService.getTransactionsForUser(userId)
                .stream()
                .map(TransactionResponse::from)
                .toList();
        return ResponseEntity.ok(responses);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TransactionResponse> getOne(@PathVariable Long id,
                                                        HttpServletRequest httpRequest) {
        Long userId = currentUserProvider.requireCurrentUserId(httpRequest);
        Transaction transaction = transactionService.getTransactionForUser(userId, id);
        return ResponseEntity.ok(TransactionResponse.from(transaction));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TransactionResponse> update(@PathVariable Long id,
                                                        @Valid @RequestBody TransactionRequest request,
                                                        HttpServletRequest httpRequest) {
        Long userId = currentUserProvider.requireCurrentUserId(httpRequest);
        Transaction updated = transactionService.updateTransaction(userId, id, request);
        return ResponseEntity.ok(TransactionResponse.from(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id, HttpServletRequest httpRequest) {
        Long userId = currentUserProvider.requireCurrentUserId(httpRequest);
        transactionService.deleteTransaction(userId, id);
        return ResponseEntity.noContent().build();
    }
}
