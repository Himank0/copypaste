package com.fintrack.transactions.dto;

import com.fintrack.transactions.model.Transaction;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * Outbound representation of a transaction. Kept separate from the
 * entity so persistence details never leak into the API contract.
 */
public record TransactionResponse(
        Long id,
        Long userId,
        BigDecimal amount,
        String category,
        String description,
        Instant createdAt
) {

    public static TransactionResponse from(Transaction transaction) {
        return new TransactionResponse(
                transaction.getId(),
                transaction.getUserId(),
                transaction.getAmount(),
                transaction.getCategory(),
                transaction.getDescription(),
                transaction.getCreatedAt()
        );
    }
}
