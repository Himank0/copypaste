package com.fintrack.transactions.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

/**
 * Inbound payload for creating or updating a transaction.
 */
public record TransactionRequest(

        @NotNull(message = "amount is required")
        @DecimalMin(value = "0.01", message = "amount must be greater than zero")
        BigDecimal amount,

        @NotBlank(message = "category is required")
        @Size(max = 60, message = "category must be 60 characters or fewer")
        String category,

        @Size(max = 255, message = "description must be 255 characters or fewer")
        String description
) {
}
