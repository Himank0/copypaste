package com.fintrack.expense.controller;

import com.fintrack.expense.dto.BalanceResponse;
import com.fintrack.expense.dto.CreateExpenseRequest;
import com.fintrack.expense.dto.ExpenseResponse;
import com.fintrack.expense.model.SharedExpense;
import com.fintrack.expense.service.ExpenseService;
import com.fintrack.security.CurrentUserProvider;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * HTTP surface for the Expense Splitting feature. Thin by design;
 * calculation and persistence live in the service layer.
 */
@RestController
@RequestMapping("/api/v1/expenses")
public class ExpenseController {

    private final ExpenseService expenseService;
    private final CurrentUserProvider currentUserProvider;

    public ExpenseController(ExpenseService expenseService, CurrentUserProvider currentUserProvider) {
        this.expenseService = expenseService;
        this.currentUserProvider = currentUserProvider;
    }

    @PostMapping
    public ResponseEntity<ExpenseResponse> create(@Valid @RequestBody CreateExpenseRequest request,
                                                    HttpServletRequest httpRequest) {
        Long userId = currentUserProvider.requireCurrentUserId(httpRequest);
        SharedExpense created = expenseService.createExpense(userId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ExpenseResponse.from(created));
    }

    @GetMapping("/balances")
    public ResponseEntity<List<BalanceResponse>> pendingBalances(HttpServletRequest httpRequest) {
        Long userId = currentUserProvider.requireCurrentUserId(httpRequest);
        return ResponseEntity.ok(expenseService.getPendingBalances(userId));
    }
}
