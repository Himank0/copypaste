package com.fintrack.expense.repository;

import com.fintrack.expense.model.SharedExpense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SharedExpenseRepository extends JpaRepository<SharedExpense, Long> {

    @Query("select distinct se from SharedExpense se " +
           "left join se.participants p " +
           "where se.creatorUserId = :userId or p.userId = :userId")
    List<SharedExpense> findAllInvolvingUser(@Param("userId") Long userId);
}
