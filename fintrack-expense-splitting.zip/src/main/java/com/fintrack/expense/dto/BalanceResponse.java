package com.fintrack.expense.dto;

import java.math.BigDecimal;

/**
 * Net balance between the requesting user and one counterpart.
 * A positive {@code netAmount} means the counterpart owes the requesting
 * user; a negative {@code netAmount} means the requesting user owes the
 * counterpart.
 */
public record BalanceResponse(Long counterpartUserId, BigDecimal netAmount) {
}
