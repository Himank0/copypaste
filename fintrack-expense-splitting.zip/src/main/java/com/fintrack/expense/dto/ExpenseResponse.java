package com.fintrack.expense.dto;

import com.fintrack.expense.model.SharedExpense;
import com.fintrack.expense.model.SplitType;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public record ExpenseResponse(
        Long id,
        Long creatorUserId,
        String description,
        BigDecimal totalAmount,
        SplitType splitType,
        List<ParticipantShareResponse> participants,
        Instant createdAt
) {

    public static ExpenseResponse from(SharedExpense expense) {
        return new ExpenseResponse(
                expense.getId(),
                expense.getCreatorUserId(),
                expense.getDescription(),
                expense.getTotalAmount(),
                expense.getSplitType(),
                expense.getParticipants().stream().map(ParticipantShareResponse::from).toList(),
                expense.getCreatedAt()
        );
    }
}
