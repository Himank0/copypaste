package com.fintrack.expense.dto;

import com.fintrack.expense.model.ExpenseParticipant;

import java.math.BigDecimal;

public record ParticipantShareResponse(Long userId, BigDecimal shareAmount) {

    public static ParticipantShareResponse from(ExpenseParticipant participant) {
        return new ParticipantShareResponse(participant.getUserId(), participant.getShareAmount());
    }
}
