package com.fintrack.expense.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/**
 * A single participant supplied when creating a shared expense.
 * {@code amount} is required for CUSTOM splits and ignored for EQUAL
 * splits (the service recalculates the equal share itself).
 */
public record ParticipantInput(

        @NotNull(message = "participant userId is required")
        Long userId,

        @DecimalMin(value = "0.00", message = "amount cannot be negative")
        BigDecimal amount
) {
}
