package com.fintrack.expense.dto;

import com.fintrack.expense.model.SplitType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.util.List;

/**
 * Inbound payload for creating a shared expense.
 */
public record CreateExpenseRequest(

        @NotBlank(message = "description is required")
        @Size(max = 255, message = "description must be 255 characters or fewer")
        String description,

        @NotNull(message = "totalAmount is required")
        @DecimalMin(value = "0.01", message = "totalAmount must be greater than zero")
        BigDecimal totalAmount,

        @NotNull(message = "splitType is required")
        SplitType splitType,

        @NotEmpty(message = "at least one participant is required")
        List<@Valid ParticipantInput> participants
) {
}
