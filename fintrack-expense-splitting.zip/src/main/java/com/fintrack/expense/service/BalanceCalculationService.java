package com.fintrack.expense.service;

import com.fintrack.common.exception.ValidationException;
import com.fintrack.expense.dto.ParticipantInput;
import com.fintrack.expense.model.ExpenseParticipant;
import com.fintrack.expense.model.SharedExpense;
import com.fintrack.expense.model.SplitType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Pure business logic for splitting a shared expense among its
 * participants and for netting balances across multiple shared
 * expenses. Contains no persistence or web concerns.
 */
@Service
public class BalanceCalculationService {

    private static final Logger log = LoggerFactory.getLogger(BalanceCalculationService.class);
    private static final BigDecimal PENNY = new BigDecimal("0.01");

    /**
     * Builds the list of {@link ExpenseParticipant} shares for a new
     * expense, validating the split rules for the given {@link SplitType}.
     *
     * @throws ValidationException if there are fewer than two participants,
     *         or (for CUSTOM splits) if the supplied amounts do not sum to the total
     */
    public List<ExpenseParticipant> calculateShares(BigDecimal totalAmount,
                                                      SplitType splitType,
                                                      List<ParticipantInput> participants) {
        if (participants == null || participants.size() < 2) {
            throw new ValidationException(
                    "A shared expense requires at least 2 participants");
        }

        return switch (splitType) {
            case EQUAL -> calculateEqualShares(totalAmount, participants);
            case CUSTOM -> calculateCustomShares(totalAmount, participants);
        };
    }

    private List<ExpenseParticipant> calculateEqualShares(BigDecimal totalAmount,
                                                            List<ParticipantInput> participants) {
        int count = participants.size();
        BigDecimal baseShare = totalAmount.divide(BigDecimal.valueOf(count), 2, RoundingMode.DOWN);
        BigDecimal distributed = baseShare.multiply(BigDecimal.valueOf(count));
        BigDecimal remainder = totalAmount.subtract(distributed); // leftover pennies from rounding

        List<ExpenseParticipant> shares = new java.util.ArrayList<>();
        for (int i = 0; i < count; i++) {
            BigDecimal share = baseShare;
            // Assign any leftover pennies to the first participants so the
            // shares always sum exactly to totalAmount.
            if (remainder.compareTo(BigDecimal.ZERO) > 0) {
                share = share.add(PENNY);
                remainder = remainder.subtract(PENNY);
            }
            shares.add(new ExpenseParticipant(participants.get(i).userId(), share));
        }
        log.debug("Calculated {} equal shares of ~{} each", count, baseShare);
        return shares;
    }

    private List<ExpenseParticipant> calculateCustomShares(BigDecimal totalAmount,
                                                             List<ParticipantInput> participants) {
        BigDecimal sum = BigDecimal.ZERO;
        for (ParticipantInput participant : participants) {
            if (participant.amount() == null) {
                throw new ValidationException(
                        "amount is required for every participant in a CUSTOM split");
            }
            sum = sum.add(participant.amount());
        }

        if (sum.setScale(2, RoundingMode.HALF_UP).compareTo(totalAmount.setScale(2, RoundingMode.HALF_UP)) != 0) {
            throw new ValidationException(
                    "Custom split amounts (" + sum + ") do not sum to the total amount (" + totalAmount + ")");
        }

        List<ExpenseParticipant> shares = new java.util.ArrayList<>();
        for (ParticipantInput participant : participants) {
            shares.add(new ExpenseParticipant(participant.userId(), participant.amount()));
        }
        return shares;
    }

    /**
     * Computes, for {@code userId}, the net balance against every other
     * user who shares at least one expense with them, across the given
     * expenses. A positive net amount means the counterpart owes
     * {@code userId}; a negative amount means {@code userId} owes the
     * counterpart.
     *
     * <p>The expense creator is treated as having paid the full total
     * amount up front; every participant (including the creator, if they
     * are also a participant) owes their calculated share back to the
     * creator.
     */
    public Map<Long, BigDecimal> computeNetBalances(Long userId, List<SharedExpense> expenses) {
        Map<Long, BigDecimal> netByCounterpart = new LinkedHashMap<>();

        for (SharedExpense expense : expenses) {
            Long creatorId = expense.getCreatorUserId();
            for (ExpenseParticipant participant : expense.getParticipants()) {
                Long participantId = participant.getUserId();
                if (participantId.equals(creatorId)) {
                    continue; // creator owing themselves is not a balance
                }
                BigDecimal share = participant.getShareAmount();

                if (participantId.equals(userId)) {
                    // userId is a participant who owes the creator.
                    accumulate(netByCounterpart, creatorId, share.negate());
                } else if (creatorId.equals(userId)) {
                    // userId is the creator; this participant owes userId.
                    accumulate(netByCounterpart, participantId, share);
                }
            }
        }
        return netByCounterpart;
    }

    private void accumulate(Map<Long, BigDecimal> map, Long counterpartId, BigDecimal delta) {
        map.merge(counterpartId, delta, BigDecimal::add);
    }
}
