package com.fintrack.expense.service;

import com.fintrack.expense.dto.BalanceResponse;
import com.fintrack.expense.dto.CreateExpenseRequest;
import com.fintrack.expense.model.ExpenseParticipant;
import com.fintrack.expense.model.SharedExpense;
import com.fintrack.expense.repository.SharedExpenseRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Coordinates persistence of shared expenses and delegates share/balance
 * math to {@link BalanceCalculationService}.
 */
@Service
public class ExpenseService {

    private static final Logger log = LoggerFactory.getLogger(ExpenseService.class);

    private final SharedExpenseRepository sharedExpenseRepository;
    private final BalanceCalculationService balanceCalculationService;

    public ExpenseService(SharedExpenseRepository sharedExpenseRepository,
                           BalanceCalculationService balanceCalculationService) {
        this.sharedExpenseRepository = sharedExpenseRepository;
        this.balanceCalculationService = balanceCalculationService;
    }

    @Transactional
    public SharedExpense createExpense(Long creatorUserId, CreateExpenseRequest request) {
        List<ExpenseParticipant> shares = balanceCalculationService.calculateShares(
                request.totalAmount(), request.splitType(), request.participants());

        SharedExpense expense = new SharedExpense(
                creatorUserId, request.description(), request.totalAmount(), request.splitType());
        shares.forEach(expense::addParticipant);

        SharedExpense saved = sharedExpenseRepository.save(expense);
        log.info("Created shared expense id={} by creatorUserId={} with {} participants",
                saved.getId(), creatorUserId, shares.size());
        return saved;
    }

    public List<BalanceResponse> getPendingBalances(Long userId) {
        List<SharedExpense> expenses = sharedExpenseRepository.findAllInvolvingUser(userId);
        Map<Long, BigDecimal> netByCounterpart = balanceCalculationService.computeNetBalances(userId, expenses);

        return netByCounterpart.entrySet().stream()
                .filter(entry -> entry.getValue().compareTo(BigDecimal.ZERO) != 0)
                .map(entry -> new BalanceResponse(entry.getKey(), entry.getValue()))
                .toList();
    }
}
