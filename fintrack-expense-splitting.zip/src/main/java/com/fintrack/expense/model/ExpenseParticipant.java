package com.fintrack.expense.model;

import jakarta.persistence.*;

import java.math.BigDecimal;

/**
 * A participant's calculated share of a {@link SharedExpense}.
 */
@Entity
@Table(name = "expense_participants")
public class ExpenseParticipant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "expense_id", nullable = false)
    private SharedExpense expense;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "share_amount", nullable = false, precision = 19, scale = 2)
    private BigDecimal shareAmount;

    protected ExpenseParticipant() {
        // for JPA
    }

    public ExpenseParticipant(Long userId, BigDecimal shareAmount) {
        this.userId = userId;
        this.shareAmount = shareAmount;
    }

    void setExpense(SharedExpense expense) {
        this.expense = expense;
    }

    public Long getId() {
        return id;
    }

    public SharedExpense getExpense() {
        return expense;
    }

    public Long getUserId() {
        return userId;
    }

    public BigDecimal getShareAmount() {
        return shareAmount;
    }
}
