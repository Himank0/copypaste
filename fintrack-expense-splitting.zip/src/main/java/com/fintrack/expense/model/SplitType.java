package com.fintrack.expense.model;

/**
 * How a shared expense's total is divided among its participants.
 */
public enum SplitType {
    EQUAL,
    CUSTOM
}
