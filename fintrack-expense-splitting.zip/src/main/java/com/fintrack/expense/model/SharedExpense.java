package com.fintrack.expense.model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * A single expense shared between a creator and a set of participants,
 * e.g. dinner, rent, or travel. The creator is treated as the party who
 * paid; each participant (which may include the creator) owes their
 * calculated share.
 */
@Entity
@Table(name = "shared_expenses")
public class SharedExpense {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "creator_user_id", nullable = false)
    private Long creatorUserId;

    @Column(nullable = false, length = 255)
    private String description;

    @Column(name = "total_amount", nullable = false, precision = 19, scale = 2)
    private BigDecimal totalAmount;

    @Enumerated(EnumType.STRING)
    @Column(name = "split_type", nullable = false, length = 20)
    private SplitType splitType;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @OneToMany(mappedBy = "expense", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ExpenseParticipant> participants = new ArrayList<>();

    protected SharedExpense() {
        // for JPA
    }

    public SharedExpense(Long creatorUserId, String description, BigDecimal totalAmount, SplitType splitType) {
        this.creatorUserId = creatorUserId;
        this.description = description;
        this.totalAmount = totalAmount;
        this.splitType = splitType;
        this.createdAt = Instant.now();
    }

    public void addParticipant(ExpenseParticipant participant) {
        participant.setExpense(this);
        this.participants.add(participant);
    }

    public Long getId() {
        return id;
    }

    public Long getCreatorUserId() {
        return creatorUserId;
    }

    public String getDescription() {
        return description;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public SplitType getSplitType() {
        return splitType;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public List<ExpenseParticipant> getParticipants() {
        return participants;
    }
}
