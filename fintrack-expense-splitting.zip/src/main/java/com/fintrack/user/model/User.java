package com.fintrack.user.model;

import jakarta.persistence.*;

/**
 * Minimal user record. FinTrack's real identity/auth service is out of
 * scope for this feature; this entity exists only so Transactions and
 * SharedExpenses have a concrete, persistent owner to enforce
 * authorisation checks against.
 */
@Entity
@Table(name = "app_user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String displayName;

    protected User() {
        // for JPA
    }

    public User(String displayName) {
        this.displayName = displayName;
    }

    public Long getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }
}
