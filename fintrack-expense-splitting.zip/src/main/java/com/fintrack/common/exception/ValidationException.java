package com.fintrack.common.exception;

/**
 * Thrown when a request violates a business/domain validation rule
 * (as opposed to a bean-validation constraint on a single field).
 */
public class ValidationException extends RuntimeException {

    public ValidationException(String message) {
        super(message);
    }
}
