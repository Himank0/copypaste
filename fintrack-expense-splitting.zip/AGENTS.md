# AGENTS.md — FinTrack Backend

This file is read by OpenAI Codex before every task in this repository
(Web, Codex app, CLI, and IDE extension). Follow it exactly. If a task
prompt conflicts with this file, this file wins.

## Technology Stack

- **Language:** Java 17
- **Framework:** Spring Boot 3.3 (Spring Web, Spring Data JPA, Spring Validation)
- **ORM:** Spring Data JPA / Hibernate — never a raw JDBC driver or hand-built SQL
- **Database:** PostgreSQL in production, H2 in-memory for local dev/tests
- **Build tool:** Maven
- **Test runner:** JUnit 5 + Mockito + AssertJ (via `spring-boot-starter-test`)

## Architecture Layer Rules

Package-per-feature, layered within each feature:

```
model      -> JPA entities only. No business logic, no repository/service calls.
repository -> Spring Data JPA interfaces only. No business logic.
service    -> All business logic, validation, and transaction boundaries
              (@Transactional). The ONLY layer allowed to call repositories.
controller -> HTTP concerns only: request/response mapping, status codes.
              MUST NOT call repositories directly. MUST NOT contain
              business logic, SQL, or validation logic beyond @Valid
              on the request body.
dto        -> Request/response records. Entities are never returned
              directly from a controller.
```

Cross-feature calls go through a feature's service class, never through
another feature's repository.

## Coding Standards

- Classes/methods: descriptive, intention-revealing names (no `doStuff`, `helper`, `tmp`).
- Use `record` for DTOs; use plain classes with private fields + getters for JPA entities.
- Every public method in `service` and `controller` packages has a Javadoc
  comment describing purpose, parameters, and exceptions thrown.
- Prefer `Optional`, `List.of(...)`, and immutable collections at API boundaries.
- Money is always `BigDecimal` with scale 2 — never `double`/`float`.
- No `System.out.println` / `printStackTrace()` — use SLF4J (`LoggerFactory.getLogger`).

## Security Rules

- **Parameterised queries / ORM only.** No string-concatenated SQL, ever, for
  any reason, even in scripts or migrations.
- **Credentials from environment variables only** (e.g. `${DB_USERNAME}`,
  `${DB_PASSWORD}`), with safe local-dev defaults in `application.yml`.
  Never hardcode a username/password/API key in source.
- **Ownership checks are mandatory** on every read/update/delete of a
  user-owned resource. The service layer must verify the resolved caller
  id matches the resource's owner before acting, and must throw
  `UnauthorizedAccessException` (mapped to HTTP 403) otherwise.
- Never trust a client-supplied user id in the request body for
  authorization decisions — resolve the caller's identity server-side
  (see `CurrentUserProvider`) and use that.
- Validate all inbound payloads with Bean Validation (`@Valid` +
  constraint annotations) plus explicit domain validation in the service
  layer for cross-field rules (e.g. custom split amounts summing to a total).

## Testing Expectations

- Minimum 80% line coverage on `service` packages.
- Unit tests for services use Mockito to mock repositories — no Spring
  context needed for pure business-logic tests.
- Mock: repositories, other services, and anything doing I/O.
- Do not mock: simple value objects, DTOs, or the class under test.
- Every new service method that enforces an authorization or validation
  rule must have at least one test asserting the failure path.

## Standing Instruction

After generating any code, summarise potential issues in three
categories — **Architecture**, **Security**, and **Performance** — even
if the list is short. Call out anything you are not confident about
rather than staying silent.
