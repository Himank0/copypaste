# REVIEW.md — Transaction Module (Inherited, Unreviewed AI-Generated Code)

**Reviewed file:** `unreviewed-ai-generated/src/transactions/TransactionController.java`
(output of the low-effort Codex prompt in `unreviewed-ai-generated/PROMPT_USED.txt`,
saved unmodified, as instructed.)

## Review Process

1. Read the diff top to bottom as if it had just landed in a PR from a teammate.
2. For every endpoint, asked: *what happens if the caller is malicious or the
   input is malformed?* — this surfaced the SQL injection and authorization gaps.
3. Traced resource lifecycle (`Connection`/`Statement`/`ResultSet`) for leaks.
4. Checked the file against `AGENTS.md` layer, security, and testing rules.
5. Codex was not re-invoked to "clean up" this file — the point of this review
   is to document what a human reviewer must catch. Remediation was done from
   scratch in Part 3 via new Codex task prompts constrained by `AGENTS.md`
   (see `PROMPTS.md`).

## Issues Found

| # | Issue | Location | Severity | Fintech Impact |
|---|-------|----------|----------|-----------------|
| 1 | SQL injection: `userId`, `amount`, `category`, `description` concatenated directly into SQL strings | `addTransaction`, `getTransactions`, `deleteTransaction`, `updateTransaction` | **Critical** | An attacker can read, modify, or delete any user's financial records, or drop tables outright, by injecting SQL through any of these string parameters. |
| 2 | No authorization/ownership check | All endpoints | **Critical** | `userId` is an unauthenticated request parameter supplied by the caller. Anyone can view, alter, or delete another user's transactions simply by passing a different id. |
| 3 | Hardcoded database credentials in source | Static fields `user`, `pass` | **Critical** | Credentials committed to version control; anyone with repo access (or a leaked build artifact) has direct DB access. |
| 4 | No ORM; raw JDBC embedded directly in the controller | Entire file | **High** | Violates the layered architecture in `AGENTS.md`; business/data-access logic is untestable in isolation and duplicated across every endpoint. |
| 5 | `Connection`, `Statement`, `ResultSet` never closed (no try-with-resources) | All endpoints | **High** | Connection pool exhaustion under load — an outage risk for an API that must reliably reflect users' money movement. |
| 6 | `amount` accepted and concatenated as a raw `String`, no type or range validation | `addTransaction`, `updateTransaction` | **High** | Malformed or negative amounts can corrupt balances; combined with issue #1, `amount` is also an injection vector, not just a data-quality one. |
| 7 | Errors swallowed with `printStackTrace()` and a bare `"error"` string, still returned with HTTP 200 | All endpoints' catch blocks | **Medium** | No structured logs for incident response; API consumers cannot distinguish success from failure by status code. |
| 8 | Raw `Map<String, Object>` returned instead of a response DTO | `getTransactions` | **Medium** | Leaks internal column names/types directly into the API contract; any schema change is a breaking API change. |
| 9 | Money represented via ad hoc `String`/JDBC types rather than `BigDecimal` | Throughout | **High** | Precision/rounding risk in a domain where cent-level accuracy matters. |

## Fix Applied

All nine issues were resolved by rewriting the module from scratch to the
standards in `AGENTS.md` rather than patching the generated file:

- `transactions/model/Transaction.java` — JPA entity, `BigDecimal` amount.
- `transactions/repository/TransactionRepository.java` — Spring Data JPA,
  no hand-written SQL.
- `transactions/service/TransactionService.java` — all business logic and
  an explicit `assertOwnership` check on every read/update/delete, resolving
  the caller's id from `CurrentUserProvider` rather than a client-supplied param.
- `transactions/controller/TransactionController.java` — thin HTTP layer,
  `@Valid` request DTOs, correct status codes.
- `common/exception/GlobalExceptionHandler.java` — structured JSON error
  responses with correct HTTP status codes; SLF4J logging throughout instead
  of `printStackTrace()`.
- Credentials moved to environment variables in `application.yml`.

## Issues Codex Introduced That Required Human Judgment

- **Trust boundary for `userId`.** Codex produced code that treats a request
  parameter as the caller's identity. Recognizing that this is the root cause
  of the authorization gap — and that the fix is to resolve identity
  server-side and enforce ownership in the service layer — required domain
  judgment about this system's actual trust boundary; nothing in a short
  prompt tells Codex where authentication happens.
- **SQL injection as a security defect, not a style preference.** The
  generated code "works" for the happy path; recognizing string-concatenated
  SQL as an exploitable vulnerability (rather than just non-idiomatic code)
  required reasoning about adversarial input, which a low-effort prompt gives
  Codex no reason to consider.
- **Money semantics.** Choosing `BigDecimal` over `String`/`double` for
  currency is a fintech-specific judgment call Codex will not make unless
  explicitly told — it is now codified in `AGENTS.md` so future generations
  get it by default.
- **What "handle the error" should actually mean.** Codex's silent
  `catch (Exception e) { return "error"; }` compiles and "works," but only a
  human evaluating this against real API consumers would flag that returning
  HTTP 200 on failure is itself a defect.
