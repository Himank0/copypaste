# ARCHITECTURE.md

Transactions and Expense Splitting are separate features that share nothing
but conventions: Expense Splitting does not read or write Transaction data,
and vice versa — a shared expense produces its own `ExpenseParticipant`
records rather than generating rows in `transactions`. They are related only
by future intent (a settled share could later post a Transaction), which is
out of scope here.

Each feature follows the same strict layering: `model` (JPA entities) →
`repository` (Spring Data JPA, zero hand-written SQL) → `service` (all
business logic, validation, and `@Transactional` boundaries — the only layer
allowed to touch a repository) → `controller` (HTTP mapping only). Data flows
in one direction on writes (controller → service → repository → DB) and
DTOs, never entities, cross the controller boundary in either direction.

`BalanceCalculationService` is deliberately pure — no repository, no entity
manager — so split math and net-balance math can be unit tested with plain
objects, independent of persistence and HTTP.

This layering suits a fintech application because it puts every rule that
touches money (split validation, rounding, ownership checks) in exactly one
place per concern, testable without a database, and keeps the controller
too simple to hide a security or logic bug.

Key decisions: ownership is resolved server-side via `CurrentUserProvider`
rather than trusted from client input (this is exactly the vulnerability
found in the inherited code in `REVIEW.md`); money is `BigDecimal`
everywhere; and equal-split rounding remainders are assigned deterministically
so results don't depend on participant ordering.
