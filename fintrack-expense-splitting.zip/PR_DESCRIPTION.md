# PR: Expense Splitting feature + Transaction module remediation

## Summary

This PR does two things as one cohesive delivery:

1. **Remediates the inherited Transaction module.** The version committed by
   a teammate was unreviewed, low-effort AI output with critical security and
   correctness issues (SQL injection, no authorization, hardcoded credentials
   — full list in `REVIEW.md`). It has been rewritten to a layered,
   ORM-based implementation with enforced per-user ownership.
2. **Adds the Expense Splitting feature** on top of the remediated
   Transaction module: a `SharedExpense`/`ExpenseParticipant` model, a
   `BalanceCalculationService` handling equal and custom splits, and two
   endpoints — create a shared expense, and get pending net balances for the
   current user.

`AGENTS.md` was added at the repo root first so both pieces of work were
generated against the same standards.

## AI Tool Disclosure

- **Codex surfaces used:** Web, CLI, and the IDE extension (see
  `TOOL_STRATEGY.md` for the full usage log and `PROMPTS.md` for the exact
  prompt chain).
- **Accepted as-is:** Transaction module remediation, `SharedExpense`/
  `ExpenseParticipant` entities, and the test suite.
- **Overrode after reviewing the diff:** `BalanceCalculationService`'s
  equal-split rounding (was non-deterministic — fixed by hand) and
  `ExpenseController` (initial version called the repository directly —
  rejected and re-prompted).
- **Estimated AI-generated vs hand-written:** ~75% Codex-generated as
  accepted, ~15% Codex-generated then hand-corrected, ~10% fully
  hand-written (the rounding fix, exception classes, and this set of docs).

## Testing Coverage

6+ test cases across `BalanceCalculationServiceTest` and
`TransactionServiceTest`:
- Equal split among 3 participants (including deterministic rounding)
- Custom split with amounts matching the total
- Custom split that doesn't sum to the total (validation failure)
- Net balance across two shared expenses between the same two users
- Single-participant expense (validation failure)
- Unauthorized access attempts on `getTransactionForUser` and `updateTransaction`

**Known gaps:**
- No controller-level (`@WebMvcTest`/`MockMvc`) or full integration
  (`@SpringBootTest`) tests yet — current coverage is service-layer unit
  tests only, so HTTP status codes and JSON serialization are unverified.
- No test for the unauthorized-delete path on `ExpenseController`'s
  endpoints (only Transaction ownership is tested end-to-end).
- No concurrency test for two simultaneous expense creations against the
  same pair of users.

## Risk / Trade-off

Settlement/payment tracking is out of scope for this PR — `getPendingBalances`
computes net balances from *every* shared expense a user has ever been part
of, with no concept of an expense being "settled" or "paid off." In
production this means balances will never shrink once created, which is
almost certainly wrong for a real product surface. Flagging this explicitly
rather than silently scoping it out, since the case study didn't specify
settlement and I didn't want to invent a data model for it unprompted.

## Self-Review Checklist

- [x] Every new endpoint resolves the caller via `CurrentUserProvider`,
      never trusts a client-supplied user id
- [x] No raw SQL / JDBC anywhere in `src/main`
- [x] All money fields are `BigDecimal`
- [x] Every public service method has a Javadoc comment
- [x] Ran the case-study-required test scenarios by hand-tracing the numbers
      (unable to execute Maven in this environment — see note below)
- [x] Checked `AGENTS.md` layer rule (controllers never call repositories)
      against every controller in the diff
- [ ] Controller-level HTTP tests (tracked as a known gap above)

**Note:** This sandbox has no network access, so `mvn test` could not be
executed to confirm the build compiles and all tests pass. Logic was
verified by manual trace instead. Please run the suite in CI before merging.

## Peer Review Simulation

> **Comment 1 — `BalanceCalculationService.calculateCustomShares`, line
> comparing `sum` to `totalAmount`**
> This compares `BigDecimal` values after `setScale(2, HALF_UP)`, which is
> correct, but there's no check that an individual participant `amount` is
> non-negative beyond the DTO's `@DecimalMin("0.00")`. A single negative
> share could still net out against a larger positive share and pass the
> sum-equals-total check. Suggest adding an explicit per-share `>= 0` check
> in the service so this isn't only enforced by DTO validation.

> **Comment 2 — `ExpenseService.getPendingBalances`**
> This loads every `SharedExpense` a user has ever participated in on every
> call, with no pagination or date bound. For a user with years of shared
> expenses this will get slow. Suggest adding a bound (e.g. only
> unsettled/recent expenses, once that concept exists) or paginating the
> underlying query.

> **Comment 3 — `CurrentUserProvider`, `X-User-Id` header**
> This is exactly the kind of thing Codex would not flag without an explicit
> AGENTS.md rule: nothing stops a caller from setting `X-User-Id` to any
> value they want at the moment, since there's no real gateway/auth
> validating it yet. Worth a comment in the class (already added) and a
> tracked follow-up ticket so this doesn't get forgotten once real auth
> lands — otherwise the ownership checks we added are enforcing authorization
> against a header anyone can forge.
