package com.fintrack.transactions;

import org.springframework.web.bind.annotation.*;
import java.sql.*;
import java.util.*;

// NOTE: This file is exactly what Codex produced from the low-effort prompt.
// Saved as-is, unreviewed, per the case study instructions.

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    static String url = "jdbc:postgresql://localhost:5432/fintrack";
    static String user = "postgres";
    static String pass = "postgres123";

    @PostMapping("/add")
    public String addTransaction(@RequestParam String userId, @RequestParam String amount,
                                  @RequestParam String category, @RequestParam String description) {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO transactions (user_id, amount, category, description) VALUES ("
                    + userId + ", " + amount + ", '" + category + "', '" + description + "')";
            stmt.executeUpdate(sql);
            return "added";
        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
    }

    @GetMapping("/get")
    public List<Map<String, Object>> getTransactions(@RequestParam String userId) throws Exception {
        List<Map<String, Object>> result = new ArrayList<>();
        Connection conn = DriverManager.getConnection(url, user, pass);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM transactions WHERE user_id = " + userId);
        while (rs.next()) {
            Map<String, Object> row = new HashMap<>();
            row.put("id", rs.getInt("id"));
            row.put("amount", rs.getDouble("amount"));
            row.put("category", rs.getString("category"));
            row.put("description", rs.getString("description"));
            result.add(row);
        }
        return result;
    }

    @DeleteMapping("/delete")
    public String deleteTransaction(@RequestParam String id) {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("DELETE FROM transactions WHERE id = " + id);
            return "deleted";
        } catch (Exception e) {
            return "error";
        }
    }

    @PutMapping("/update")
    public String updateTransaction(@RequestParam String id, @RequestParam String amount) {
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("UPDATE transactions SET amount = " + amount + " WHERE id = " + id);
            return "updated";
        } catch (Exception e) {
            return "error";
        }
    }
}
