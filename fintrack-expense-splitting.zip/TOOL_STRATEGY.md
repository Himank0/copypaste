# TOOL_STRATEGY.md

## Codex Usage Log

| # | Surface | Task & why this surface | Review method | Outcome |
|---|---------|--------------------------|----------------|---------|
| 1 | Web | Simulated the low-effort "inherit unreviewed code" prompt for the Transaction module. Web was used because this step is meant to represent a teammate's one-off, undirected task, not an integrated dev-loop action. | N/A — deliberately saved unreviewed per the exercise. | Saved as-is to `unreviewed-ai-generated/`; reviewed separately in `REVIEW.md`. |
| 2 | Web | Full remediation of the Transaction module (model/repository/service/controller) against AGENTS.md. Web suits a large, multi-file generation where I want to read the whole diff before touching the repo. | Full diff view, file by file. | Accepted with no changes — matched AGENTS.md on first pass. |
| 3 | IDE extension | Adding the `SharedExpense` / `ExpenseParticipant` entities inline, next to the existing `Transaction` entity. IDE extension suits small, file-scoped additions where seeing surrounding code in context helps get conventions right. | Inline diff preview in the editor. | Accepted with no changes. |
| 4 | Web | `BalanceCalculationService` — the highest-risk business logic in the feature (money math). Wanted the full method bodies visible at once to check rounding and validation logic carefully. | Full diff view + manual trace of the equal-split remainder logic by hand. | Modified — rewrote the rounding-remainder assignment to be deterministic (see PROMPTS.md). |
| 5 | CLI | Wiring `ExpenseService` + `ExpenseController`, a mechanical "connect these layers" task with no design ambiguity — a good fit for a scripted/batch CLI invocation. | `git diff` after `codex exec` completed. | Modified — rejected an initial version that called the repository from the controller; re-ran with a restated constraint. |
| 6 | Web | Generating the test suite from a few-shot example of an existing test class. Web was used to paste in the example test file alongside the prompt. | Full diff view; ran tests against the same assertions manually to sanity check expected values (e.g. the 33.34/33.33/33.33 split). | Accepted with no changes. |

## Scenario Responses

- **You need a quick, isolated one-line bug fix in a file you already have open.**
  IDE extension — inline diff preview lets you accept a small, localized
  change without breaking flow to a browser tab, and the surrounding code is
  already in context for Codex.

- **You need to regenerate the same kind of boilerplate across many files
  in a repeatable, scriptable way (e.g. adding a new field to several DTOs).**
  CLI — `codex exec` composes with shell scripting and is easiest to re-run
  identically across files or wire into a pre-commit/CI step.

- **You're designing a new, non-trivial piece of business logic and want to
  read and reason about the entire generated file before it touches the repo.**
  Web — the full-page diff view is the easiest surface for carefully reading
  a large, unfamiliar generation end-to-end before accepting anything.

## Limitations Encountered

1. **What I prompted:** The initial `BalanceCalculationService` prompt
   (decomposition technique, Prompt 3 in `PROMPTS.md`).
   **What went wrong:** The equal-split logic assigned all rounding
   remainder to the last participant in the list, so the result depended on
   participant ordering rather than being deterministic.
   **How I detected it:** Manual review — traced a 3-way $100 split by hand
   and noticed reordering the input list changed who received the extra cent.
   **How I fixed it:** Manually rewrote the remainder-distribution loop to
   assign leftover cents to the first N participants in a fixed order, then
   added a test asserting the exact per-participant amounts.
   **Next time:** State the determinism requirement explicitly in the
   original prompt instead of catching it after the fact.

2. **What I prompted:** The CLI task to wire `ExpenseController` to
   `ExpenseService` (Prompt 4).
   **What went wrong:** The generated controller injected
   `SharedExpenseRepository` directly for the `/balances` endpoint "for
   simplicity," bypassing the service layer and violating the AGENTS.md
   layering rule.
   **How I detected it:** `git diff` review before committing — the extra
   repository import stood out immediately against the existing pattern.
   **How I fixed it:** Rejected the diff and re-ran the CLI prompt with the
   layering constraint restated explicitly rather than assumed from AGENTS.md alone.
   **Next time:** Treat "controllers must not call repositories" as a rule
   to restate per-prompt for CLI batch tasks, not just something to rely on
   AGENTS.md to enforce silently.

3. **What I prompted:** The original low-effort Transaction prompt
   (Part 2 of the case study, submitted verbatim).
   **What went wrong:** Everything documented in `REVIEW.md` — SQL
   injection, no ORM, no authorization, hardcoded credentials, unclosed
   JDBC resources.
   **How I detected it:** Manual code review, simulating malicious input
   against every endpoint before writing any remediation code.
   **How I fixed it:** Did not patch the file — rewrote the entire module
   from scratch under AGENTS.md constraints (see Prompt 1).
   **Next time:** This was a deliberate simulation of unreviewed code, so
   "differently" here means: this is exactly why AGENTS.md and mandatory
   review exist before any Codex output reaches `main`.
